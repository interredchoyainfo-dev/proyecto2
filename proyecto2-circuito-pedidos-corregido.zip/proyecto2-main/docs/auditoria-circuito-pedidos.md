# Auditoría del circuito de pedidos — Complejo Giovanni

## Cambios incluidos

- El menú confirma el pedido mediante una única acción de estado, crea/actualiza el pedido en una sola mutación del store y bloquea el doble clic durante la confirmación.
- Cuando el pedido corresponde a una mesa con un pedido activo, agrega los nuevos productos al pedido activo más reciente en lugar de crear otro pedido.
- La confirmación marca el pedido como `confirmado`; cocina lo recibe automáticamente sin requerir un segundo envío manual.
- La pantalla de cocina muestra todos los productos de un pedido confirmado, incluidos bebidas, café y productos que tengan destino de comanda `bar`.
- Los controles “Enviar a Cocina” del mozo y de mesas solo aparecen para pedidos en borrador. La acción no vuelve a confirmar ni notificar un pedido ya confirmado.
- El sondeo de SQLite/API solo completa la carga inicial si el negocio todavía no tiene pedidos en el store. Firestore fusiona las versiones remotas por ID y no vacía el estado cuando su colección está vacía, evitando que una respuesta retrasada o una colección aún no migrada haga desaparecer pedidos.
- Las actualizaciones de Firestore reemplazan únicamente los datos del negocio activo y conservan los pedidos de otros negocios en el store compartido.
- La persistencia toma el identificador del negocio desde el pedido y compara el contenido de los objetos antes de escribir; esto evita cruces entre negocios y escrituras repetidas causadas por nuevas referencias de objetos en snapshots.
- La carga inicial de mesas desde la API se usa solo si todavía no hay mesas del negocio en el store; los snapshots de Firestore ya no reemplazan las mesas de otros negocios.
- La búsqueda de pedido activo por mesa prioriza el pedido activo más recientemente actualizado.

## Validaciones ejecutadas

- `node --check server/index.js`: correcto.
- Transpilación sintáctica con TypeScript global de los siete archivos modificados: correcta.
- `tsc -b`: no pudo completar la comprobación de tipos porque no estaban instaladas las dependencias del proyecto (`vite/client` y tipos de Node no disponibles). La instalación de dependencias no terminó en este entorno.

## Alcance y precauciones

Este paquete es una copia de trabajo basada en el ZIP proporcionado en la conversación. No se modificó ningún repositorio remoto de GitHub. Antes de desplegar, debe ejecutarse `npm ci`, `npm run build` y una prueba real con dos sesiones simultáneas (cliente/mozo y cocina) conectadas al Firebase del negocio correcto.
