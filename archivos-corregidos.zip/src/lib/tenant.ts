import { useParams, useLocation } from 'react-router-dom';
import { getApiTenant } from './api';

export const normalizeTenant = (value?: string | null): string =>
  String(value ?? '').toLowerCase().trim();

/** Negocio activo según la URL (/:negocioId/...). Fuente única de verdad en el frontend. */
export function getActiveTenant(): string {
  return normalizeTenant(getApiTenant());
}

/**
 * ¿La entidad pertenece al negocio? Los registros locales antiguos sin negocioId
 * se consideran de 'giovanni' (compatibilidad); todo registro nuevo se crea con su negocioId.
 */
export function belongsToTenant(
  entity: { negocioId?: string | null } | null | undefined,
  tenantId?: string | null
): boolean {
  if (!entity) return false;
  return normalizeTenant(entity.negocioId || 'giovanni') === normalizeTenant(tenantId || getApiTenant());
}

/** Hook: negocio de la ruta actual; se actualiza al navegar entre negocios. */
export function useTenantId(): string {
  const { negocioId } = useParams<{ negocioId?: string }>();
  useLocation();
  return normalizeTenant(negocioId || getApiTenant());
}
